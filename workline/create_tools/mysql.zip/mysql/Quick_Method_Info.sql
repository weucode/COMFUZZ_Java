/*
 Navicat Premium Data Transfer

 Source Server         : 213-10205
 Source Server Type    : MySQL
 Source Server Version : 80027
 Source Host           : 117.34.212.213:10205
 Source Schema         : JVMFuzzing

 Target Server Type    : MySQL
 Target Server Version : 80027
 File Encoding         : 65001

 Date: 17/02/2023 00:45:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Quick_Method_Info
-- ----------------------------
DROP TABLE IF EXISTS `Quick_Method_Info`;
CREATE TABLE `Quick_Method_Info`  (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `Class_Name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Method_Name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Param_Info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Boundary_Value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Return_Type` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Throws_Desc` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `Import_Stmt` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `Class_Page` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1561 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of Quick_Method_Info
-- ----------------------------
INSERT INTO `Quick_Method_Info` VALUES (1543, 'AtomicIntegerArray', 'length', '{\"\": \"\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1544, 'AtomicIntegerArray', 'get', '{\"i\": \"int\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1545, 'AtomicIntegerArray', 'set', '{\"i\": \"int\", \"newValue\": \"int\"}', '{}', 'void', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1546, 'AtomicIntegerArray', 'lazySet', '{\"i\": \"int\", \"newValue\": \"int\"}', '{}', 'void', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1547, 'AtomicIntegerArray', 'getAndSet', '{\"i\": \"int\", \"newValue\": \"int\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1548, 'AtomicIntegerArray', 'compareAndSet', '{\"i\": \"int\", \"expect\": \"int\", \"update\": \"int\"}', '{}', 'boolean', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1549, 'AtomicIntegerArray', 'weakCompareAndSet', '{\"i\": \"int\", \"expect\": \"int\", \"update\": \"int\"}', '{}', 'boolean', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1550, 'AtomicIntegerArray', 'getAndIncrement', '{\"i\": \"int\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1551, 'AtomicIntegerArray', 'getAndDecrement', '{\"i\": \"int\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1552, 'AtomicIntegerArray', 'getAndAdd', '{\"i\": \"int\", \"delta\": \"int\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1553, 'AtomicIntegerArray', 'incrementAndGet', '{\"i\": \"int\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1554, 'AtomicIntegerArray', 'decrementAndGet', '{\"i\": \"int\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1555, 'AtomicIntegerArray', 'addAndGet', '{\"i\": \"int\", \"delta\": \"int\"}', '{}', 'int', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1556, 'AtomicIntegerArray', 'getAndUpdate', '{\"i\": \"int\", \"updateFunction\": \"IntUnaryOperator\"}', '{}', 'int', NULL, 'import java.util.function.IntUnaryOperator;\n', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1557, 'AtomicIntegerArray', 'updateAndGet', '{\"i\": \"int\", \"updateFunction\": \"IntUnaryOperator\"}', '{}', 'int', NULL, 'import java.util.function.IntUnaryOperator;\n', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1558, 'AtomicIntegerArray', 'getAndAccumulate', '{\"i\": \"int\", \"x\": \"int\", \"accumulatorFunction\": \"IntBinaryOperator\"}', '{}', 'int', NULL, 'import java.util.function.IntBinaryOperator;\n', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1559, 'AtomicIntegerArray', 'accumulateAndGet', '{\"i\": \"int\", \"x\": \"int\", \"accumulatorFunction\": \"IntBinaryOperator\"}', '{}', 'int', NULL, 'import java.util.function.IntBinaryOperator;\n', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');
INSERT INTO `Quick_Method_Info` VALUES (1560, 'AtomicIntegerArray', 'toString', '{\"\": \"\"}', '{}', 'String', NULL, '', 'https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicIntegerArray.html');

SET FOREIGN_KEY_CHECKS = 1;
