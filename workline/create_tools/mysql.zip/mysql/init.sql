CREATE TABLE `Table_Function` (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  Function_content longtext COLLATE utf8mb4_bin,
  SourceFun_id int(11) DEFAULT NULL,
  Mutation_method int(11) DEFAULT NULL,
  Mutation_times int(11) DEFAULT NULL,
  Remark longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`)
);
CREATE TABLE `Table_Testcase` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Testcase_context` longtext COLLATE utf8mb4_bin,
  `SourceFun_id` int(11) DEFAULT NULL,
  `SourceTestcase_id` int(11) DEFAULT NULL,
  `Fuzzing_times` int(11) DEFAULT NULL,
  `Mutation_method` int(11) DEFAULT NULL,
  `Mutation_times` int(11) DEFAULT NULL,
  `Interesting_times` int(11) DEFAULT NULL,
  `Probability` int(11) DEFAULT NULL,
  `Remark` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`)
);
CREATE TABLE `Table_Testbed` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Testbed_name` longtext COLLATE utf8mb4_bin,
  `Testbed_version` longtext COLLATE utf8mb4_bin,
  `Testbed_location` longtext COLLATE utf8mb4_bin,
  `Remark` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`)
);
CREATE TABLE `Table_Result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Testcase_id` int(11) DEFAULT NULL,
  `Testbed_id` int(11) DEFAULT NULL,
  `Returncode` int(11) DEFAULT NULL,
  `Stdout` longtext COLLATE utf8mb4_bin,
  `Stderr` longtext COLLATE utf8mb4_bin,
  `Duration_ms` int(11) DEFAULT NULL,
  `Seed_coverage` decimal(5,3) DEFAULT NULL,
  `Engine_coverage` decimal(5,3) DEFAULT NULL,
  `Remark` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`)
);
CREATE TABLE `Table_Suspicious_Result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Error_type` longtext COLLATE utf8mb4_bin,
  `Testcase_id` int(11) DEFAULT NULL,
  `Function_id` int(11) DEFAULT NULL,
  `Testbed_id` int(11) DEFAULT NULL,
  `Remark` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`)
);
CREATE TABLE `Table_javac_Result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Testcase_id` int(11) DEFAULT NULL,
  `Testbed_id` int(11) DEFAULT NULL,
  `Returncode` int(11) DEFAULT NULL,
  `Stdout` longtext COLLATE utf8mb4_bin,
  `Stderr` longtext COLLATE utf8mb4_bin,
  `Duration_ms` int(11) DEFAULT NULL,
  `Seed_coverage` decimal(5,3) DEFAULT NULL,
  `Engine_coverage` decimal(5,3) DEFAULT NULL,
  `Remark` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`)
);
CREATE TABLE `Table_javac_Suspicious_Result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Error_type` longtext COLLATE utf8mb4_bin,
  `Testcase_id` int(11) DEFAULT NULL,
  `Function_id` int(11) DEFAULT NULL,
  `Testbed_id` int(11) DEFAULT NULL,
  `Remark` longtext COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`)
);

INSERT INTO `Table_Testbed` VALUES (1, 'HotSpot-jdk8', '8.0.332', '/root/jvm/openjdk8/jdk8u332-b02/build/linux-x86_64-normal-server-release/jdk/bin/java', NULL);
INSERT INTO `Table_Testbed` VALUES (2, 'HotSpot-jdk11', '11.0.14', '/root/jvm/openjdk11/jdk-11.0.14.1-ga/build/linux-x86_64-normal-server-release/images/jdk/bin/java', NULL);
INSERT INTO `Table_Testbed` VALUES (3, 'Openj9-jdk8', '8u342-ga', '/root/jvm/openj9-jdk8/openj9-jdk8_0723/openj9-openjdk-jdk8/build/linux-x86_64-normal-server-release/images/j2sdk-image/bin/java', NULL);
INSERT INTO `Table_Testbed` VALUES (4, 'Openj9-jdk11', '11.0.16+8', '/root/jvm/openj9-jdk11/openj9-jdk11_0723/openj9-openjdk-jdk11/build/linux-x86_64-normal-server-release/images/jdk/bin/java', NULL);
INSERT INTO `Table_Testbed` VALUES (5, 'GraalVM-jdk11', '22.0.0.2', '/root/jvm/graal-jdk11/graalvm-ce-java11-22.0.0.2/bin/java', NULL);
